#pragma once

#define SUPABASE_REST_URL "https://pwtiwifutxpbcwpxuwxw.supabase.co"
#define SUPABASE_ANON_KEY "sb_publishable_jllnJuPXFYBh0uZsY8y6Fw_3SU9czGX"

// nao adicionar WiFi SSID/senha aqui: a professora configura pelo qr code.